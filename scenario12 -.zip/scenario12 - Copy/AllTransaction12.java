package com.sims.scenario12;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.sims.scenario13.CommonClass;

public class AllTransaction12 {
	
	public static void main(String[] args) throws Exception {
		ChromeDriver driver = CommonClass.getchromedriver();
		Actions action = new Actions(driver);

		CreateNewAccount12 account = new CreateNewAccount12();
		account.createAccount(driver, action);
		
		NewSubmission12 submission= new NewSubmission12();
		submission.newSubmission(driver, action);
		
		PolicyChange change = new PolicyChange();
		change.changePolicy(driver, action);
		
		PolicyCancellation cancel = new PolicyCancellation();
		cancel.cancelpolicy(driver, action);
		
		ReWriteNewTerm rewrite = new ReWriteNewTerm();
		rewrite.rewriteNewTerm(driver, action);
	}

}
